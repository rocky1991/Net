fallocate -l 1M test.txt
scp -i key1.pem test.txt ubuntu@18.237.114.0:/home/ubuntu